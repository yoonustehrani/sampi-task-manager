

<?php $__env->startSection('title'); ?>
افزودن اولویت
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/proiorities/create.blade.php ENDPATH**/ ?>