<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sampi Tech Group</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome.css')); ?>">
</head>
<body>
    <div class="col-12 h-100 float-left main-division">
        <div class="col-md-6 col-12 float-left mb-md-0 mb-3 p-3 left-section">
            <div class="logo-section">
                <img src="<?php echo e(asset('images/logo/sampi.png')); ?>" alt="">
                <p class="m-0">Sampi Tech Group</p>
            </div>
        </div>
        <div class="col-md-6 col-12 float-left mb-md-0 mb-3 p-3 right-section">
            <p class="col-12 float-left text-center"><i class="fas fa-list"></i> ماژول ها</p>
            <div class="float-left module-section">
                <ul class="col-md-6 col-12 p-0 module-list float-right">
                    <li><a href="<?php echo e(route('task-manager.')); ?>"><i class="fas fa-briefcase"></i> مدیریت یکپارچه پروژه ها</a></li>
                </ul>
                <ul class="col-md-6 col-12 p-0 module-list float-right">
                    
                </ul>
            </div>
        </div>
    </div>
</body>
</html>

<?php /**PATH W:\php\sampies\resources\views/index.blade.php ENDPATH**/ ?>