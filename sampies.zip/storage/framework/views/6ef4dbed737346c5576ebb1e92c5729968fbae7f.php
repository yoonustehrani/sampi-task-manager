

<?php $__env->startSection('title'); ?>
وظایف من
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div
        id="mixed-tasks-react"
        get-mixed-tasks-api="<?php echo e(route('api.task-manager.tasks.mixed', ['api_token' => auth()->user()->api_token])); ?>"
        data-search="<?php echo e(route('api.task-manager.tasks.search', ['api_token' => auth()->user()->api_token])); ?>"
        simple-search="<?php echo e(route('api.task-manager.tasks.search.simple', ['api_token' => auth()->user()->api_token])); ?>"
        workspaces-api="<?php echo e(route('api.task-manager.workspaces.index', ['api_token' => auth()->user()->api_token])); ?>"
        add_task_api = "<?php echo e(route('api.task-manager.tasks.store', ['workspace' => "workspaceId", 'api_token' => auth()->user()->api_token])); ?>"
        logged-in-user-id = "<?php echo e(auth()->user()->id); ?>"
    >
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const CAN_VIEW_AS_ADMIN = <?php echo e(\Gate::allows('viewAny', \App\Task::class) ? 'true' : 'false'); ?>;
        var VIEW_AS_ADMIN       = <?php echo e(request()->view_as_admin == 'true' ? 'true' : 'false'); ?>; 
        var simple_search_url = "<?php echo e(route('api.task-manager.tasks.search.simple', ['api_token' => auth()->user()->api_token])); ?>"
    </script>
    <script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/mixedTasks.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/tasks/index.blade.php ENDPATH**/ ?>