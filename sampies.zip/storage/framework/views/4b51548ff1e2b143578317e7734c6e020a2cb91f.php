

<?php $__env->startSection('title'); ?>
لیست اولویت ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست اولویت ها', 'create' => route('task-manager.proiorities.create')]); ?>
        
    <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('theme.tools.table'); ?>
        <?php $__env->startComponent('theme.tools.table-head'); ?>
            <th scope="col">#</th>
            <th scope="col">عنوان</th>
            <th scope="col">آیکون</th>
            <th scope="col">ویرایش</th>
            <th scope="col">حذف</th>
        <?php if (isset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151)): ?>
<?php $component = $__componentOriginal613bb4727af9d76286df5789b006b71cca5af151; ?>
<?php unset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('theme.tools.table-body'); ?>
            <?php $__currentLoopData = $proiorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proiority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <?php echo e($loop->index + 1); ?>

                    </th>
                    <td>
                        <?php echo e($proiority->title); ?>

                    </td>
                    <td>
                        <?php if($proiority->icon_class): ?>
                            <span class="<?php echo e($proiority->color_class ? 'text-' . $proiority->color_class : ''); ?>">
                                <i class="<?php echo e($proiority->icon_class); ?> fa-2x"></i>
                            </span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('task-manager.proiorities.edit', ['proiority' => $proiority->id])); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                    </td>
                    <td>
                        <form action="<?php echo e(route('task-manager.proiorities.destroy', ['proiority' => $proiority->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b)): ?>
<?php $component = $__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b; ?>
<?php unset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39)): ?>
<?php $component = $__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39; ?>
<?php unset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/proiorities/index.blade.php ENDPATH**/ ?>