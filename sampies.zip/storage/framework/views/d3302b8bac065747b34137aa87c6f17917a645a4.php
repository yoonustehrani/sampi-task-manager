<table class="table table-striped table-bordered <?php echo e(isset($class) ? $class : ''); ?> float-right table-responsive w-100 d-block d-md-table">
    <?php echo $slot; ?>

</table><?php /**PATH W:\php\sampies\resources\views/theme/tools/table.blade.php ENDPATH**/ ?>