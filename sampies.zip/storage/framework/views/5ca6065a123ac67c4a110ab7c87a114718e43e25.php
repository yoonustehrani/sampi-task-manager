

<?php $__env->startSection('title'); ?>
همه درخواست ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div 
        id="mixed-demands-react"
        data-index="<?php echo e(route('api.task-manager.demands.mixed', ['api_token' => auth()->user()->api_token])); ?>"
        
        data-store="<?php echo e(route('api.task-manager.demands.store', ['workspace' => 'workspaceId', 'api_token' => auth()->user()->api_token])); ?>"
        data-show="<?php echo e(route('api.task-manager.demands.show', ['workspace' => 'workspaceId', 'demand' => 'demandId'])); ?>"
        data-destroy="<?php echo e(route('api.task-manager.demands.destroy', ['workspace' => 'workspaceId', 'demand' => 'demandId'])); ?>"
        logged-in-user-id = "<?php echo e(auth()->user()->id); ?>"
        data-search="<?php echo e(route('api.task-manager.demands.search', ['api_token' => auth()->user()->api_token])); ?>"
        workspaces-api="<?php echo e(route('api.task-manager.workspaces.index', ['api_token' => auth()->user()->api_token])); ?>"
        get-all-users="<?php echo e(route('api.task-manager.users.index', ['api_token' => auth()->user()->api_token])); ?>"
    >
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const CAN_VIEW_AS_ADMIN = <?php echo e(\Gate::allows('viewAny', \App\Demand::class) ? 'true' : 'false'); ?>;
        var VIEW_AS_ADMIN       = <?php echo e(request()->view_as_admin == 'true' ? 'true' : 'false'); ?>; 
        var simple_search_url = "<?php echo e(route('api.task-manager.tasks.search.simple', ['api_token' => auth()->user()->api_token])); ?>"
    </script>
    <script src="<?php echo e(asset('js/mixedDemands.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/demands/mixed.blade.php ENDPATH**/ ?>