

<?php $__env->startSection('title'); ?>
پروژه (<?php echo e($workspace->title); ?>)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="col-md-10 offset-md-1 col-12">
        <div class="col-12 float-right mb-3 pr-0 pl-0 pr-md-3 pl-md-3 animated flipInY">
            <img class="float-right" src="<?php echo e(asset($workspace->avatar_pic)); ?>" style="height: 50px; widht: 50px;" alt="">
            <h4 class="text-right mt-3">
                <?php echo e($workspace->title); ?>

            </h4>
        </div>
        <div class="workspace-sub-info float-right col-12">
            <span><i class="fas fa-tasks ml-1 animated heartBeat delay-2s"></i><span class="number ml-1"><?php echo e($workspace->tasks_count); ?></span>مسئولیت</span>
            <span><i class="fas fa-thumbtack ml-1 animated heartBeat delay-2s"></i><span class="number ml-1"><?php echo e($workspace->tasks_count - $workspace->finished_tasks_count); ?></span>مسئولیت جاری</span>
            <span><i class="far fa-check-square ml-1 animated heartBeat delay-2s"></i><span class="number ml-1"><?php echo e($workspace->finished_tasks_count); ?></span>مسئولیت انجام شده</span>
            <a style="direction: rtl;" href="<?php echo e(route('task-manager.demands.index', ['workspace' => $workspace->id])); ?>">
                <span><i class="far fa-check-square ml-1 animated heartBeat delay-2s"></i><span class="number ml-1"><?php echo e($workspace->demands_count); ?></span><b>خواسته ها</b></span>
            </a>
            <span><i class="far fa-comments ml-1 animated heartBeat delay-2s"></i><span class="number ml-1"><?php echo e($workspace->demands_left_count); ?></span>خواسته جاری</span>
            <span><i class="far fa-check-circle ml-1 animated heartBeat delay-2s"></i><span class="number ml-1"><?php echo e($workspace->demands_count -  $workspace->demands_left_count); ?></span>خواسته انجام شده</span>
        </div>
        <div class="col-12 float-right pr-0 pl-0 pr-md-3 pl-md-3 animated flipInX">
            <div class="title-section workspace-title-section col-12">
                <i class="fas fa-user-secret"></i>
                <h4 class="">اعضا (<?php echo e(count($workspace->users)); ?>):</h4>      
            </div>    
            <div class="col-12">
            <?php $__env->startComponent('theme.tools.table', ['class' => 'table-sm']); ?>
                <?php $__env->startComponent('theme.tools.table-head'); ?>
                    <th scope="col">#</th>
                    <th scope="col">نام</th>
                    <th scope="col">وضعیت</th>
                    <th scope="col">سمت سازمانی</th>
                <?php if (isset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151)): ?>
<?php $component = $__componentOriginal613bb4727af9d76286df5789b006b71cca5af151; ?>
<?php unset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('theme.tools.table-body'); ?>
                    <?php $__currentLoopData = $workspace->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row">
                                <?php echo e($loop->index + 1); ?>

                            </th>
                            <td>
                                <div class="name-col-user-workspace text-right">
                                    <div class="user-info-workspace ml-2">
                                        <img src="<?php echo e(asset($user->avatar_pic ?: 'images/male-avatar.svg')); ?>" alt="">
                                        <a class="mr-2" href="<?php echo e(route('task-manager.users.show', ['user' => $user->id])); ?>"><?php echo e($user->fullname); ?></a>
                                    </div>
                                    <?php if($user->pivot->is_admin): ?>
                                        <span class="badge badge-dark">ادمین</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="no-break">
                                مسئولیت : <span class="badge badge-warning ml-md-4 d-block d-md-inline mb-1 mb-md-0"><?php echo e($user->tasks_count); ?> <i class="fas fa-briefcase"></i></span>
                                درخواست : <span class="badge badge-primary ml-md-4 d-block d-md-inline mb-1 mb-md-0"><?php echo e($user->asked_demands_count); ?> <i class="fas fa-arrow-down"></i></span>
                                نیاز : <span class="badge badge-danger ml-md-4 d-block d-md-inline mb-1 mb-md-0"><?php echo e($user->demands_count); ?> <i class="fas fa-arrow-up"></i></span>
                            </td>
                            <td>
                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(! $loop->last): ?>
                                        <?php echo e($role->label); ?>،
                                    <?php else: ?>
                                        <?php echo e($role->label); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b)): ?>
<?php $component = $__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b; ?>
<?php unset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            <?php if (isset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39)): ?>
<?php $component = $__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39; ?>
<?php unset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div>
        <div
            id="workspace-react"
            list_tasks_api = "<?php echo e(route('api.task-manager.tasks.index', ['workspace' => $workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
            add_task_api = "<?php echo e(route('api.task-manager.tasks.store', ['workspace' => $workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
            task_route = "<?php echo e(route('task-manager.tasks.show', ['task' => 'taskId'])); ?>"
            workspace_api = "<?php echo e(route('api.task-manager.workspaces.show', ['workspace' => $workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
            get-all-users="<?php echo e(route('api.task-manager.users.index', ['api_token' => auth()->user()->api_token])); ?>"
        ></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const CAN_VIEW_AS_ADMIN = <?php echo e(\Gate::allows('update', $workspace) ? 'true' : 'false'); ?>;
        var VIEW_AS_ADMIN       = <?php echo e(request()->view_as_admin == 'true' ? 'true' : 'false'); ?>; 
        var simple_search_url = "<?php echo e(route('api.task-manager.tasks.search.simple', ['api_token' => auth()->user()->api_token])); ?>"
    </script>
    <script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/workspace.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/workspaces/show.blade.php ENDPATH**/ ?>