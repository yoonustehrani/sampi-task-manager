

<?php $__env->startSection('title'); ?>
لیست سمت ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Role::class)): ?>
        <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست سمت ها', 'create' => route('task-manager.roles.create')]); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست سمت ها']); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
    <?php $__env->startComponent('theme.tools.table'); ?>
        <?php $__env->startComponent('theme.tools.table-head'); ?>
            <th scope="col">#</th>
            <th scope="col">عنوان</th>
            <th scope="col">کلید</th>
            <?php if(auth()->user()->hasPermission('can_update_roles')): ?>
            <th scope="col">ویرایش</th>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('can_delete_roles')): ?>
            <th scope="col">حذف</th>
            <?php endif; ?>
        <?php if (isset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151)): ?>
<?php $component = $__componentOriginal613bb4727af9d76286df5789b006b71cca5af151; ?>
<?php unset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('theme.tools.table-body'); ?>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <?php echo e($loop->index + 1); ?>

                    </th>
                    <td>
                        <?php echo e($role->label); ?>

                    </td>
                    <td>
                        <?php echo e($role->name); ?>

                    </td>
                    <?php if(auth()->user()->hasPermission('can_update_roles')): ?>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $role)): ?>
                        <a href="<?php echo e(route('task-manager.roles.edit', ['role' => $role->id])); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                    <?php if(auth()->user()->hasPermission('can_delete_roles')): ?>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $role)): ?>
                        <form action="<?php echo e(route('task-manager.roles.destroy', ['role' => $role->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                        </form>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b)): ?>
<?php $component = $__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b; ?>
<?php unset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39)): ?>
<?php $component = $__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39; ?>
<?php unset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/roles/index.blade.php ENDPATH**/ ?>