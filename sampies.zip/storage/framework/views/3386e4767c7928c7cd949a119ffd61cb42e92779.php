<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Chart.js</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <p>
        <?php echo e(route('api.task-manager.chart.tasks', ['type' => 'completed'])); ?>

    </p>
    <div class="col-md-6 float-left p-3">
        <canvas id="myChart" aria-label="Hello ARIA World" role="img"></canvas>
    </div>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chart.js')); ?>"></script>
    <script>
        let ctx = document.getElementById('myChart');
        
        let data = [
            <?php $__currentLoopData = $task_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task_day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                y: <?php echo e(rand(0,100)); ?>,
                t: moment("<?php echo e($task_day->date->format('Y-m-d')); ?>").format("jYYYY-jMM-jDD")
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];
        // var startDate = moment('2020-12-21').format('jYYYY-jMM-jDD');
        // var endDate = moment('2021-01-20').format('jYYYY-jMM-jDD');
        var myLineChart = new Chart(ctx, {
            type: 'line',
            data: {
                
                // labels: [startDate, endDate],
                datasets: [
                    {
                        label: 'وظایف',
                        // showLine: false,
                        lineTension: 0.5,
                        data: data,
                        // fill: false,
                        borderColor: 'red',
                        borderWidth: 1,
                        backgroundColor: 'rgba(255,0,0,0.2)',
                    }
                ]
            },
            options: {
                tooltips: {
                    mode: 'index',
                    intersect: false,
                    titleFontFamily: 'Iransans',
                    bodyFontFamily: 'Iransans'
                },
                legend: {
                    labels: {
                        fontFamily: 'Iransans'
                    }
                },
                scales: {
                    xAxes: [
                        {
                            ticks: {
                                source: 'auto',
                                fontFamily: 'Iransans'
                            },
                            distribution: 'series',
                            type: 'time',
                            time: {
                                round: true,
                                unit: 'day',
                                minUnit: 'day',
                                tooltipFormat: 'dddd، DD MMMM jYYYY',
                                displayFormats: {
                                    'day': 'YYYY-MM-DD',
                                },
                            }
                        }
                    ],
                    yAxes: [{
                        stacked: false,
                        ticks: {
                            beginAtZero: true,
                            fontFamily: 'Iransans',
                            suggestedMin: 0,
                            suggestedMax: 100,
                        }
                    }]
                },
                elements: {
                    // point: {
                    //     pointBackgroundColor: '',
                    //     pointBorderColor: '',
                    //     pointBorderWidth: '',
                    // },
                    // lines: {
                    //     backgroundColor: 'red',
                    // }
                }
            }
        });
    </script>
</body>
</html><?php /**PATH W:\php\sampies\resources\views/chart.blade.php ENDPATH**/ ?>