<?php echo e($slot); ?>

<?php /**PATH W:\php\sampies\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>