

<?php $__env->startSection('title'); ?>
افزودن پروژه
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php $__env->startComponent('theme.tools.title', ['title' => 'ایجاد پروژه جدید']); ?><?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <form class="col-12 float-left p-0 form-group text-right" action="<?php echo e(route('task-manager.workspaces.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input required type="text" value="<?php echo e(old('title')); ?>" name="title" id="title" class="form-control" placeholder="<?php echo e(__('title')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-image"></i></span>
            </div>
            <input type="text" value="<?php echo e(old('avatar_pic')); ?>" name="avatar_pic" id="avatar_pic" class="form-control text-left d-ltr" placeholder="<?php echo e(__('avatar_pic')); ?>">
        </div>
        <br><br><br>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user-tag"></i></span>
            </div>
            <select name="members[]" id="members" class="form-control text-right" multiple>
                <option></option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->fullname); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br><br><br>
        <div class="col-lg-6 col-md-6 col-12 input-group float-right mb-3">
            <textarea required rows="10" name="description" id="description" class="form-control" placeholder="<?php echo e(__('description')); ?>"><?php echo e(old('description')); ?></textarea>
        </div>
        <div class="col-12 p-3 float-right text-right">
            <button type="submit" class="btn btn-outline-primary"><?php echo e(__('save')); ?></button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#members').select2({
            placeholder: "<?php echo e(__('employees')); ?>"
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/workspaces/create.blade.php ENDPATH**/ ?>