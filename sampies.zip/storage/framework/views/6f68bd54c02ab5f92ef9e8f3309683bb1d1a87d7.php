<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script>
        var APP_PATH = "<?php echo e(asset('/')); ?>";
        const USER_ROUTE = "<?php echo e(route('task-manager.users.show', ['user' => 'userId'])); ?>",
        TASK_ROUTE = "<?php echo e(route('task-manager.tasks.show', ['task' => 'taskId'])); ?>",
        WORKSPACE_ROUTE = "<?php echo e(route('task-manager.workspaces.show', ['workspace' => 'workspaceId'])); ?>",
        DEMAND_ROUTE = "<?php echo e(route('task-manager.demands.show', ['workspace' => 'workspaceId', 'demand' => 'demandId'])); ?>",
        PRIORITY_ROUTE = "<?php echo e(route('api.task-manager.priorities.index')); ?>";
        <?php if(auth()->guard()->check()): ?>
        const CurrentUser = <?php echo json_encode(auth()->user()->only(['id', 'fullname', 'avatar_pic'])); ?>;
        <?php endif; ?>
    </script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->make('partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH W:\php\sampies\resources\views/layouts/default.blade.php ENDPATH**/ ?>