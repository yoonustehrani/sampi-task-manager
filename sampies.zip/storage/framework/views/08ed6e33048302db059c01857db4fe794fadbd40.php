

<?php $__env->startSection('title'); ?>
لیست پروژه ها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Workspace::class)): ?>
    <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست پروژه ها', 'create' => route('task-manager.workspaces.create')]); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست پروژه ها']); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
    
    <?php $__env->startComponent('theme.tools.table'); ?>
        <?php $__env->startComponent('theme.tools.table-head'); ?>
            <th scope="col">#</th>
            <th scope="col">عنوان پروژه</th>
            <th scope="col">کارمندان</th>
            <th scope="col">وضعیت وظایف</th>
            <th scope="col">نیاز های جاری</th>
            <?php if(auth()->user()->hasPermission('can_update_workspaces')): ?>
            <th scope="col">ویرایش</th>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('can_delete_workspaces')): ?>
            <th scope="col">حذف</th>
            <?php endif; ?>
        <?php if (isset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151)): ?>
<?php $component = $__componentOriginal613bb4727af9d76286df5789b006b71cca5af151; ?>
<?php unset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('theme.tools.table-body'); ?>
            <?php $__currentLoopData = $workspaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workspace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <?php echo e($loop->index + 1); ?>

                    </th>
                    <td class="text-right">
                        <img src="<?php echo e(asset($workspace->avatar_pic ?: 'images/male-avatar.svg')); ?>" alt="" style="height: 30px; widh: 30px;">
                        <a href="<?php echo e(route('task-manager.workspaces.show', ['workspace' => $workspace->id])); ?>"><?php echo e($workspace->title); ?></a>
                    </td>
                    <td>
                        <div class="employees-container horizontal-centerlize">
                            <?php if(count($workspace->users) > 1): ?>
                                <span><?php echo e(count($workspace->users)); ?> <i class="fas fa-users"></i></span>
                            <?php elseif(count($workspace->users)): ?>
                                <span><i class="fas fa-user"></i></span>
                            <?php else: ?>
                                <i class="fas fa-user-slash"></i>
                            <?php endif; ?>
                            <div class="dropdown-users d-none">
                                <?php $__currentLoopData = $workspace->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="user-dropdown-item animated jackInTheBox">
                                        <div class="user-right-flex">
                                            <div class="user-img-container ml-2">
                                                <img src="<?php echo e(asset($user->avatar_pic ?: 'images/male-avatar.svg')); ?>" />
                                            </div>
                                            <div class="user-info ml-2">
                                                <p><?php echo e($user->fullname); ?></p>
                                                <a href=""><?php echo e("@".$user->name); ?></a>
                                            </div>
                                        </div>
                                        <div class="user-label-container">
                                            <?php if($user->pivot->is_admin == 1): ?>
                                                <button class="btn btn-sm btn-success rtl admin"><span>ادمین<i class="fas fa-user-tie mr-1"></i></span></button>
                                            <?php else: ?>
                                                <button class="btn btn-sm btn-primary rtl"><span>عضو<i class="fas fa-user mr-1"></i></span></button>
                                            <?php endif; ?> 
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </td>
                    <td class="no-break">
                        کل : <span class="badge badge-primary ml-md-4 d-block d-md-inline mb-1 mb-md-0"><?php echo e($workspace->tasks_count); ?></span>
                        اتمام : <span class="badge badge-success ml-md-4 d-block d-md-inline mb-1 mb-md-0"><?php echo e($workspace->finished_tasks_count); ?></span>
                        باقی مانده : <span class="badge badge-danger ml-md-4 d-block d-md-inline mb-1 mb-md-0"><?php echo e($workspace->tasks_count - $workspace->finished_tasks_count); ?></span>
                    </td>
                    <td>
                        <?php echo e($workspace->demands_left_count); ?>

                    </td>
                    <?php if(auth()->user()->hasPermission('can_update_workspaces')): ?>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $workspace)): ?>
                        <a href="<?php echo e(route('task-manager.workspaces.edit', ['workspace' => $workspace->id])); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                    <?php if(auth()->user()->hasPermission('can_delete_workspaces')): ?>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $workspace)): ?>
                        <form action="<?php echo e(route('task-manager.workspaces.destroy', ['workspace' => $workspace->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b)): ?>
<?php $component = $__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b; ?>
<?php unset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39)): ?>
<?php $component = $__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39; ?>
<?php unset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="col-12 p-0 float-right text-center mt-3 mb-4">
        <?php echo e($workspaces->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/workspaces/index.blade.php ENDPATH**/ ?>