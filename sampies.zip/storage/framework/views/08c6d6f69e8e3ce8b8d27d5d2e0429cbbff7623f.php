<div class="col-12 float-right mb-3">
    <?php echo e($slot); ?>

    <h2 class="text-right">
        <?php if(isset($create)): ?>
        <a class="btn btn-info" href="<?php echo e($create); ?>"><i class="fas fa-plus"></i></a>
        <?php endif; ?>
        <?php echo e($title); ?>

    </h2>
</div><?php /**PATH W:\php\sampies\resources\views/theme/tools/title.blade.php ENDPATH**/ ?>