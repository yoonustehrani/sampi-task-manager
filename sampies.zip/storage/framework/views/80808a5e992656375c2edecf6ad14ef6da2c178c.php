

<?php $__env->startSection('title'); ?>
لیست کاربران
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\User::class)): ?>
        <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست کاربران', 'create' => route('task-manager.users.create')]); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست کاربران']); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php endif; ?>
    <?php $__env->startComponent('theme.tools.table'); ?>
        <?php $__env->startComponent('theme.tools.table-head'); ?>
            <th scope="col">#</th>
            <th scope="col">نام خانوادگی</th>
            <th scope="col">نام کاربری</th>
            <th scope="col">ایمیل</th>
            <th scope="col">chat id تلگرام</th>
            <th scope="col">سمت ها</th>
            <th scope="col">ویرایش</th>
            <?php if(auth()->user()->hasPermission('can_delete_users')): ?>
            <th scope="col">حذف</th>
            <?php endif; ?>
        <?php if (isset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151)): ?>
<?php $component = $__componentOriginal613bb4727af9d76286df5789b006b71cca5af151; ?>
<?php unset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('theme.tools.table-body'); ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <?php echo e($loop->index + 1); ?>

                    </th>
                    <td class="text-right">
                        <img src="<?php echo e(asset($user->avatar_pic ?: 'images/male-avatar.svg')); ?>" alt="" style="height: 30px; widh: 30px;">
                        <?php echo e($user->fullname); ?>

                    </td>
                    <td>
                        <span class="mr-3"><?php echo e($user->name); ?></span>
                    </td>
                    <td>
                        <?php echo e($user->email); ?>

                    </td>
                    <td>
                        <?php if($user->telegram_chat_id): ?>
                            <?php echo e($user->telegram_chat_id); ?>

                        <?php else: ?>
                            <span class="text-secondary"><em>ندارد</em></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if(! $user->roles->count()): ?>
                            <span class="text-secondary"><em>ندارد</em></span>
                        <?php endif; ?>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a target="_blank" href="<?php echo e(route('task-manager.roles.edit', ['role' => $role->id])); ?>" class="badge badge-<?php echo e(b4_random_color_class()); ?> p-2"><?php echo e($role->label); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $user)): ?>
                        <a href="<?php echo e(route('task-manager.users.edit', ['user' => $user->id])); ?>" class="btn btn-sm btn-primary">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                    <?php if(auth()->user()->hasPermission('can_delete_users')): ?>
                    <td>
                        <?php if(auth()->user()->id !== $user->id): ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $user)): ?>
                            <form action="<?php echo e(route('task-manager.users.destroy', ['user' => $user->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b)): ?>
<?php $component = $__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b; ?>
<?php unset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39)): ?>
<?php $component = $__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39; ?>
<?php unset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="col-12 p-0 float-right text-center mt-3 mb-4">
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/users/index.blade.php ENDPATH**/ ?>