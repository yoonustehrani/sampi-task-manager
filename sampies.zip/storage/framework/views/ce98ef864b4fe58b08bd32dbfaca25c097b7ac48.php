<?php if($errors->any()): ?>
<script>
    Swal.default.fire({
        icon: 'error',
        title: 'خطا',
        html: "<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo "<p class='col-12 float-right text-center'>"; ?><?php echo e($err); ?><?php echo "</p><br>"; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>",
        showConfirmButton	: true,
        customClass: {
            content: 'persian-text'
        }
    })
</script>
<?php endif; ?><?php /**PATH W:\php\sampies\resources\views/partials/error.blade.php ENDPATH**/ ?>