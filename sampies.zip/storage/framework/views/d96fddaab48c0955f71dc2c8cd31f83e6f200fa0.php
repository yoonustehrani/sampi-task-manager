

<?php $__env->startSection('title'); ?>
درخواست ها در پروژه (<?php echo e($workspace->title); ?>)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div 
        id="demands-react"
        data-index="<?php echo e(route('api.task-manager.demands.index', ['workspace' => $workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
        
        data-store="<?php echo e(route('api.task-manager.demands.store', ['workspace' => $workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
        data-show="<?php echo e(route('api.task-manager.demands.show', ['workspace' => $workspace->id, 'demand' => 'demandId'])); ?>"
        data-destroy="<?php echo e(route('api.task-manager.demands.destroy', ['workspace' => $workspace->id, 'demand' => 'demandId'])); ?>"
        user-profile-route="<?php echo e(route('task-manager.users.show', ['user' => 'userId'])); ?>"
        task-route="<?php echo e(route('task-manager.tasks.show', ['task' => 'taskId'])); ?>"
        workspace-api = "<?php echo e(route('api.task-manager.workspaces.show', ['workspace' => $workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
        logged-in-user-id = "<?php echo e(auth()->user()->id); ?>"
        demand-route="<?php echo e(route('task-manager.demands.show', ['workspace' => $workspace->id, 'demand' => 'demandId'])); ?>"
        get-all-users="<?php echo e(route('api.task-manager.users.index', ['api_token' => auth()->user()->api_token])); ?>"
    >
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const CAN_VIEW_AS_ADMIN = <?php echo e(\Gate::allows('update', $workspace) ? 'true' : 'false'); ?>;
        var VIEW_AS_ADMIN       = <?php echo e(request()->view_as_admin == 'true' ? 'true' : 'false'); ?>;
        var simple_search_url = "<?php echo e(route('api.task-manager.tasks.search.simple', ['api_token' => auth()->user()->api_token])); ?>"
    </script>
    <script src="<?php echo e(asset('js/demands.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/demands/index.blade.php ENDPATH**/ ?>