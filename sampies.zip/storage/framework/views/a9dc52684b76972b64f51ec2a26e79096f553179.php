

<?php $__env->startSection('title'); ?>
افزودن مجوز
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php $__env->startComponent('theme.tools.title', ['title' => 'ایجاد مجوز جدید']); ?><?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <form class="col-12 float-left p-0 form-group text-right" action="<?php echo e(route('task-manager.permissions.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-tag"></i></span>
            </div>
            <input type="text" value="<?php echo e(old('label')); ?>" name="label" id="label" class="form-control" placeholder="<?php echo e(__('label')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-key"></i></span>
            </div>
            <input type="text" value="<?php echo e(old('key')); ?>" name="key" id="key" class="form-control" placeholder="<?php echo e(__('key')); ?>">
        </div>
        <div class="col-12 p-3 float-right text-right">
            <button type="submit" class="btn btn-outline-primary"><?php echo e(__('save')); ?></button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/permissions/create.blade.php ENDPATH**/ ?>