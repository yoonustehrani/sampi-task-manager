<thead class="thead-dark">
    <tr>
        <?php echo $slot; ?>

    </tr>
</thead><?php /**PATH W:\php\sampies\resources\views/theme/tools/table-head.blade.php ENDPATH**/ ?>