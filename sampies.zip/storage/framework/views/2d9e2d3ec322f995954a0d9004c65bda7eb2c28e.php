

<?php $__env->startSection('title'); ?>
درخواست ها - <?php echo e($demand->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="col-12 p-0 float-left h-100">
        <div class="col-lg-3 col-md-5 col-sm-12 col-12 float-right ticket-info-section p-3 mb-3">
            <div class="box-section p-0">
                <div class="box-header p-0 col-12 float-left">
                    <div class="box-icon">
                        <i class="fas fa-exclamation text-dark"></i>
                    </div>
                    <p class="box-header-title">اطلاعات درخواست
                        <span data-id="<?php echo e($demand->priority->id); ?>" id="react-state-priority">
                        <?php if($demand->priority->icon_class): ?>
                            (<?php echo e($demand->priority->title); ?> <i class="text-<?php echo e($demand->priority->color_class); ?> <?php echo e($demand->priority->icon_class); ?>"></i>)
                        <?php else: ?>
                            (<?php echo e($demand->priority->title); ?>)
                        <?php endif; ?>
                        </span>
                    </p>
                </div>
                <div class="box-body p-0 col-12 float-12">
                    <div class="box-body-row col-6">
                        <b>شماره :</b> #<?php echo e($demand->id); ?>

                    </div>
                    <div class="box-body-row col-12" id="react-state-title">
                        <b>عنوان :</b> <span><?php echo e($demand->title); ?></span>
                    </div>
                    <div class="box-body-row col-12">
                        <b>از :</b>
                        <a href="<?php echo e(route('task-manager.users.show', ['user' => $demand->from->id])); ?>" class="avatar-pic text-secondary">
                            <img src="<?php echo e(asset($demand->from->avatar_pic ?: 'images/male-avatar.svg')); ?>" alt="">
                            <?php if($demand->from->id == auth()->user()->id): ?> من <?php else: ?> <?php echo e($demand->from->fullname); ?> <?php endif; ?>
                        </a>
                    </div>
                    <div class="box-body-row col-12">
                        <b>به :</b>
                        <a href="<?php echo e(route('task-manager.users.show', ['user' => $demand->to->id])); ?>" class="avatar-pic text-secondary">
                            <img src="<?php echo e(asset($demand->to->avatar_pic ?: 'images/male-avatar.svg')); ?>" alt="">
                            <?php if($demand->to->id == auth()->user()->id): ?> من <?php else: ?> <?php echo e($demand->to->fullname); ?> <?php endif; ?>
                        </a>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $demand)): ?>
                    <div class="box-body-row col-12 text-center">
                        <form action="<?php echo e(route('task-manager.demands.destroy', ['demand' => $demand->id, 'workspace' => $workspace->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger btn-sm">حذف <i class="fas fa-trash"></i></button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="box-section mt-3 p-0">
                <div class="box-header p-0 col-12 float-left">
                    <div class="box-icon">
                        <i class="fas fa-briefcase text-dark"></i>
                    </div>
                    <p class="box-header-title">اطلاعات پروژه 
                        <span class="avatar-pic">
                            <img src="<?php echo e(asset($demand->workspace->avatar_pic ?: 'male-avatar.svg')); ?>" alt="">
                        </span>
                    </p>
                </div>
                <div class="box-body p-0 col-12 float-12">
                    <div class="box-body-row col-12">
                        <b>عنوان :</b>
                        <a href="<?php echo e(route('task-manager.workspaces.show', ['workspace' => $workspace->id])); ?>" title="<?php echo e($workspace->title); ?>" class="avatar-pic text-secondary">
                            <?php echo e($workspace->title); ?>

                        </a>
                    </div>
                    <div class="box-body-row col-12">
                        <b>توضیحات :</b>
                        <?php echo e(\Illuminate\Support\Str::words($workspace->description, 30, '...')); ?>

                    </div>
                </div>
            </div>
            <div class="box-section mt-3 p-0">
                <div class="box-header p-0 col-12 float-left">
                    <div class="box-icon">
                        <i class="far fa-clock text-dark"></i>
                    </div>
                    <p class="box-header-title">اطلاعات زمانی</p>
                </div>
                <div class="box-body p-0 col-12 float-12">
                    <div class="box-body-row col-12">
                        <b>تاریخ ارسال :</b>
                        <?php echo e($demand->created_at); ?>

                    </div>
                    <div class="box-body-row col-12">
                        <b>آخرین ویرایش :</b>
                        <?php echo e($demand->updated_at->diffForHumans()); ?>

                    </div>
                    <?php if(count($demand->messages) > 0): ?>
                    <div id="last-message" class="box-body-row col-12">
                        <b>آخرین پیام :</b>
                        <span><?php echo e($demand->messages[0]->updated_at->diffForHumans()); ?></span>
                    </div>
                    <?php else: ?>
                    <div id="last-message" class="box-body-row col-12 d-none">
                        <b>آخرین پیام :</b>
                        <span></span>
                    </div>
                    <?php endif; ?>
                    <?php if($demand->finished_at): ?>
                    <div class="box-body-row col-12">
                        <b>بسته شده :</b>
                        <?php echo e($demand->finished_at->diffForHumans()); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if($demand->task): ?>
            <?php
                $demand->task->load('workspace')
            ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $demand)): ?>
            <div class="box-section mt-3 p-0">
                <div class="box-header p-0 col-12 float-left">
                    <div class="box-icon">
                        <i class="fas fa-tasks text-dark"></i>
                    </div>
                    <p class="box-header-title">وظیفه مربوطه</p>
                </div>
                <div class="box-body p-0 col-12 float-12">
                    <div class="box-body-row col-12">
                        <b>عنوان :</b>
                        <a href="<?php echo e(route('task-manager.tasks.show', ['task' => $demand->task->id])); ?>">
                            <?php echo e($demand->task->title); ?>

                        </a>
                    </div>
                    <div class="box-body-row col-12">
                        <b>پروژه :</b>
                        <a href="<?php echo e(route('task-manager.workspaces.show', ['workspace' => $demand->task->workspace->id])); ?>" title="<?php echo e($demand->task->workspace->title); ?>" class="avatar-pic text-secondary">
                            <img src="<?php echo e(asset($demand->task->workspace->avatar_pic ?: 'male-avatar.svg')); ?>" alt="<?php echo e($demand->task->workspace->title); ?>">
                            <?php echo e($demand->task->workspace->title); ?>

                        </a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="col-lg-9 col-md-7 col-sm-12 col-12 float-right p-3 mb-3 h-100">
            <div
                class="h-100"
                id="react-demand-show"
                data-apiKey="<?php echo e(auth()->user()->api_token); ?>"
                data-messages="<?php echo e(route('api.task-manager.demands.messages.index', ['demand' => $demand->id])); ?>"
                data-message="<?php echo e(route('api.task-manager.demands.messages.store', ['demand' => $demand->id])); ?>"
                data-show="<?php echo e(route('api.task-manager.demands.show', ['demand' => $demand->id, 'workspace' => $workspace->id])); ?>"
                data-update="<?php echo e(route('api.task-manager.demands.update', ['workspace' => $workspace->id, 'demand' => $demand->id])); ?>"
                data-toggle="<?php echo e(route('api.task-manager.demands.toggle_state', ['demand' => $demand->id])); ?>">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/demand.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/demands/show.blade.php ENDPATH**/ ?>