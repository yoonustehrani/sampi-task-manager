

<?php $__env->startSection('title'); ?>
داشبورد
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div 
        id = "react-dashboard"
        workspace_route = "<?php echo e(route('task-manager.workspaces.show', ['workspace' => 'workspaceId'])); ?>"
        task_route = "<?php echo e(route('task-manager.tasks.show', ['task' => 'taskId'])); ?>"
        workspace_counter = "<?php echo e(route('api.task-manager.counter.workspaces', ['api_token' => auth()->user()->api_token])); ?>"
        task_counter = "<?php echo e(route('api.task-manager.counter.tasks', ['api_token' => auth()->user()->api_token])); ?>"
        demand_counter = "<?php echo e(route('api.task-manager.counter.demands', ['api_token' => auth()->user()->api_token])); ?>"
        workspaces = "<?php echo e(route('api.task-manager.workspaces.index', ['api_token' => auth()->user()->api_token])); ?>"
        mixed_tasks = "<?php echo e(route('api.task-manager.tasks.mixed', ['api_token' => auth()->user()->api_token])); ?>"
        mixed_demands = "<?php echo e(route('api.task-manager.demands.mixed', ['api_token' => auth()->user()->api_token])); ?>"
        demand-show-route="<?php echo e(route('task-manager.demands.show', ['workspace' => 'workspaceId', 'demand' => 'demandId'])); ?>"
        user-profile-route="<?php echo e(route('task-manager.users.show', ['user' => 'userId'])); ?>"
    ></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('/js/dashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/dashboard.blade.php ENDPATH**/ ?>