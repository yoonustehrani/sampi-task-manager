<tbody>
    <?php echo $slot; ?>

</tbody><?php /**PATH W:\php\sampies\resources\views/theme/tools/table-body.blade.php ENDPATH**/ ?>