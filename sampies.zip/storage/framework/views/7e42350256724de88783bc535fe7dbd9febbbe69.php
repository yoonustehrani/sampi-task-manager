

<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<div
    id = "react-show-task"
    task_api = "<?php echo e(route('api.task-manager.tasks.show', ['workspace' => $task->workspace->id, 'task' => $task->id, 'api_token' => auth()->user()->api_token])); ?>"
    workspace_api = "<?php echo e(route('api.task-manager.workspaces.show', ['workspace' => $task->workspace->id, 'api_token' => auth()->user()->api_token])); ?>"
    logged_in_user_id = "<?php echo e(auth()->user()->id); ?>"
    edit_task_api = "<?php echo e(route('api.task-manager.tasks.update', ['workspace' => $task->workspace->id, 'task' => $task->id, 'api_token' => auth()->user()->api_token])); ?>"
    toggle_task_state_api = "<?php echo e(route('api.task-manager.tasks.toggle_state', ['workspace' => $task->workspace->id, 'task' => $task->id, 'api_token' => auth()->user()->api_token])); ?>"
></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var simple_search_url = "<?php echo e(route('api.task-manager.tasks.search.simple', ['api_token' => auth()->user()->api_token])); ?>"
    </script>
    <script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset("/js/task.js")); ?>"></script>
    <script src="<?php echo e(asset('js/select2.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/tasks/show.blade.php ENDPATH**/ ?>