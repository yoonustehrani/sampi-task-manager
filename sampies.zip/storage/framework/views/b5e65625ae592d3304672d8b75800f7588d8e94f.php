

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?>| <?php echo e(config('app.name')); ?></title>
    <style>
        table {
            direction: rtl;
            text-align: center;
        }
        form {
            direction: rtl;
        }
        .d-ltr {
            direction: ltr;
        }
        .d-rtl {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-12 admin-area p-0 m-0 h-12">
        <div class="col-lg-2 col-md-3 d-md-block h-12 p-0 collapsed" id="right-menu">
            <div class="top-section col-12 text-center float-left">
                <button class="btn btn-secondary d-md-none float-right collapser-btn">
                    <i class="fas fa-angle-double-left"></i>
                </button>
                <img class="logo-top" src="<?php echo e(asset('images/logo/sampi.png')); ?>" alt="sampi-tech-group">
                <p class="col-12 m-0 mt-1 p-0 float-right text-center">Task Manager</p>
            </div>
            <?php echo $__env->make('theme.tools.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 h-12" id="mainpage">
            <?php echo $__env->make('theme.tools.top-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="contentbar col-12 float-left mt-3">
                <?php echo $__env->yieldContent('page-content'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/panel.blade.php ENDPATH**/ ?>