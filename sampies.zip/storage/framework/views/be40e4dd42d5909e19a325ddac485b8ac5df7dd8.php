

<?php $__env->startSection('title'); ?>
لیست مسئولیت های پروژه <?php echo e($workspace->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $workspace)): ?>
    <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست مسئولیت های پروژه ' . $workspace->title , 'create' => route('task-manager.workspaces.tasks.create', ['workspace' => $workspace->id])]); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('theme.tools.title', ['title' => 'لیست مسئولیت های پروژه ' . $workspace->title ]); ?> <?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php endif; ?>

    <?php $__env->startComponent('theme.tools.table'); ?>
        <?php $__env->startComponent('theme.tools.table-head'); ?>
            <th scope="col">#</th>
            <th scope="col">عنوان پروژه</th>
            <th scope="col">کارمندان</th>
            <th scope="col">وضعیت وظایف</th>
            <th scope="col">نیاز های جاری</th>
            <?php if(auth()->user()->hasPermission('can_update_tasks')): ?>
            <th scope="col">ویرایش</th>
            <?php endif; ?>
            <?php if(auth()->user()->hasPermission('can_delete_tasks')): ?>
            <th scope="col">حذف</th>
            <?php endif; ?>
        <?php if (isset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151)): ?>
<?php $component = $__componentOriginal613bb4727af9d76286df5789b006b71cca5af151; ?>
<?php unset($__componentOriginal613bb4727af9d76286df5789b006b71cca5af151); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('theme.tools.table-body'); ?>
            
        <?php if (isset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b)): ?>
<?php $component = $__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b; ?>
<?php unset($__componentOriginal8dea14c228011d35e8baaf22cb36ebcf30cd757b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php if (isset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39)): ?>
<?php $component = $__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39; ?>
<?php unset($__componentOriginalbf6ddaa362f42b3cb3f6390b00b99991aafada39); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="col-12 p-0 float-right text-center mt-3 mb-4">
        <?php echo e($tasks->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/workspace-tasks/index.blade.php ENDPATH**/ ?>