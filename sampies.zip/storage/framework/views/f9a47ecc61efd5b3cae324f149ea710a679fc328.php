

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<style>
input:-webkit-autofill,
input:-webkit-autofill:hover, 
input:-webkit-autofill:focus, 
input:-webkit-autofill:active  {
  transition: background-color 5000s;
  -webkit-text-fill-color: #fff !important;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-12">
    <div class="card col-lg-4 col-md-6 col-sm-10 offset-lg-4 offset-md-3 offset-sm-1 text-center">
        <!-- <div class="avatar-container mb-4">
            <img src="<?php echo e(asset('/images/male-avatar.svg')); ?>" alt=""></img>
        </div> -->
        <div class="avatar-container mb-4">
            <img src="<?php echo e(asset('/images/logo/sampi.png')); ?>" alt=""></img>
        </div>
        <form action="<?php echo e(route('login')); ?>" method="post" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input autocomplete="false" name="hidden" type="text" class="hidden">
            <div class="form-group input-group mb-4">
                <div class="input-group-prepend">
                    <i class="fas fa-user-tie input-icon"></i>
                </div>
                <input type="email" name="email" class="auth-input form-control text-center" placeholder="Email Address" autocomplete="off">
            </div>
            <div class="form-group input-group mb-4">
                <div class="input-group-prepend">
                    <i class="fas fa-key input-icon"></i>
                </div>
                <input type="password" name="password" class="auth-input form-control text-center" placeholder="Password" autocomplete="off">
            </div>
            <button class="btn btn-outline-light text-center" type="submit">Login</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/auth/login.blade.php ENDPATH**/ ?>