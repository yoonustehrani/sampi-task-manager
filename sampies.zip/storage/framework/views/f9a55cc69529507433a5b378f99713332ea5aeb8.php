

<?php $__env->startSection('title'); ?>
ویرایش کاربر (<?php echo e($user->name); ?>)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php $__env->startComponent('theme.tools.title', ['title' => "ویرایش کاربر {$user->name}"]); ?><?php if (isset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416)): ?>
<?php $component = $__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416; ?>
<?php unset($__componentOriginalcf421c51e19bc8c7393592c02150bfa19a6a6416); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <form class="col-12 float-left p-0 form-group text-right" action="<?php echo e(route('task-manager.users.update', ['user' => $user->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input required type="text" value="<?php echo e(old('name') ?: $user->name); ?>" name="name" id="name" class="form-control text-left d-ltr" placeholder="<?php echo e(__('username')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input required type="text" value="<?php echo e(old('first_name') ?: $user->first_name); ?>" name="first_name" id="first_name" class="form-control" placeholder="<?php echo e(__('first_name')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user"></i></span>
            </div>
            <input type="text" value="<?php echo e(old('last_name') ?: $user->last_name); ?>" name="last_name" id="last_name" class="form-control" placeholder="<?php echo e(__('last_name')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="far fa-envelope"></i></span>
            </div>
            <input required type="text" value="<?php echo e(old('email') ?: $user->email); ?>" name="email" id="email" class="form-control text-left d-ltr" placeholder="<?php echo e(__('email')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-lock"></i></span>
            </div>
            <input type="password" name="password" id="password" class="form-control text-left d-ltr" placeholder="<?php echo e(__('password')); ?>">
        </div>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-lock"> 2 </i></span>
            </div>
            <input type="password" name="password_confirmation" id="password_confirmation" class="form-control text-left d-ltr" placeholder="<?php echo e(__('confirm') . ' ' . __('password')); ?>">
        </div>
        <?php if(auth()->user()->hasRole('developer')): ?>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-image"></i></span>
            </div>
            <input type="text" value="<?php echo e(old('avatar_pic') ?: $user->avatar_pic); ?>" name="avatar_pic" id="avatar_pic" class="form-control text-left d-ltr" placeholder="<?php echo e(__('avatar_pic')); ?>">
        </div>
        <?php endif; ?>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-paper-plane"></i></span>
            </div>
            <input type="text" value="<?php echo e(old('telegram_chat_id') ?: $user->telegram_chat_id); ?>" name="telegram_chat_id" id="telegram_chat_id" class="form-control text-left d-ltr" placeholder="<?php echo e(__('telegram_chat_id')); ?>">
        </div>
        <?php if(auth()->user()->hasPermission('can_edit_user_role')): ?>
        <div class="col-lg-4 col-md-6 col-12 input-group float-right mb-3">
            <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-user-tag"></i></span>
            </div>
            <select name="roles[]" id="roles" class="form-control text-right" multiple>
                <option></option>
            </select>
        </div>
        <?php endif; ?>
        <div class="col-12 p-3 float-right text-right">
            <button type="submit" class="btn btn-outline-primary"><?php echo e(__('save')); ?></button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if(auth()->user()->hasPermission('can_edit_user_role')): ?>
    <script>
        let roles_route = "<?php echo e(route('api.task-manager.roles.index')); ?>";
        let roles_of_user_route = "<?php echo e(route('api.task-manager.user.roles', ['user' => $user->id])); ?>";
        axios.get(roles_route).then(res => {
            let roles = res.data;
            axios.get(roles_of_user_route).then(res => {
                let user_roles = res.data;
                if (roles.length > 0 && user_roles) {
                    roles.map(perm => {
                        let found = !! user_roles.find(item => item.name === perm.name);
                        if (! found) {
                            $('#roles').append(`<option value="${perm.id}">${perm.label ? perm.label + ' - ' : ''}${perm.name}</option>`)
                        } else {
                            $('#roles').append(`<option selected value="${perm.id}">${perm.label ? perm.label + ' - ' : ''}${perm.name}</option>`)
                        }
                    })
                }
                $('#roles').select2({
                    placeholder: "<?php echo e(__('roles')); ?>"
                });
            })
        }) 
    </script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('theme.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\php\sampies\resources\views/theme/pages/users/edit.blade.php ENDPATH**/ ?>