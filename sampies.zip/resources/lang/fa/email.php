<?php

return [
    'greeting' => 'سلام',
    'Regards' => 'با احترام',
    'app' => [
        'name' => 'Elnovel - ال ناول'
    ],
    'subcopy' => "اگر حین کلیک کردن روی دکمه \":actionText\" مشکلی داشتید " . "می توانید لینک زیر را در مرورگر خود وارد نمایید [:actionURL](:actionURL)",
];