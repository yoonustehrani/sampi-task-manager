<thead class="thead-dark">
    <tr>
        {!! $slot !!}
    </tr>
</thead>