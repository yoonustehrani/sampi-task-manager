<tbody>
    {!! $slot !!}
</tbody>