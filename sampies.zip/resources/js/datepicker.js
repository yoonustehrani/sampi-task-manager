window.persianDate = require('persian-date');
window.persianDatepicker = require('persian-datepicker/dist/js/persian-datepicker');