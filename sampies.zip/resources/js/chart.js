import 'moment/locale/fa';

window.Chart = require('chart.js');
Chart.platform.disableCSSInjection = true;
