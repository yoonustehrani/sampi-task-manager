<table class="table table-striped table-bordered {{ isset($class) ? $class : '' }} float-right table-responsive w-100 d-block d-md-table">
    {!! $slot !!}
</table>